

<p>用户：<?php echo $user['username']?></p>
<p>积分为：<?php echo $user['integral']?></p>
<p>邮箱：<?php echo $user['email']?></p>
<p>手机号：<?php echo $user['tel']?></p>